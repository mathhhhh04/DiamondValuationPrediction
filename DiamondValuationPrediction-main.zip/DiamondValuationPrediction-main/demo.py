# demo.py

def main():
    print("Welcome to this repository, developed by the students of Data Science and Artificial Intelligence from PUC-SP, belonging to group 5 of HACKAPUC-SP 2nd edition, who won the 1st place in the competition of February 2024!")
    print("This is my demonstration file in Python.")
    print("It contains code related to the MindfulAl-Copilots-Bots HACKAPUC-SP.")
    print("Feel free to explore and contribute!")

if __name__ == "__main__":
    main()



def main():
    print("Seja muito bem-vindo a este repositório, desenvolvido pelos alunos de Ciência de Dados e Inteligência Artificial da PUC-SP, pertencentes ao grupo 5 do HACKAPUC-SP 2ª edição, que conquistaram o 1º lugar na competição de fevereiro de 2024!")
    print("ste é o meu arquivo de demonstração em Python.")
    print("Ele contém código relacionado à 2ª edição do HACKAPUC-SP.")
    print("Sinta-se à vontade para explorar e contribuir!")

if __name__ == "__main__":
    main()

